/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package code;
import java.util.Date;


/**
 *
 * @author Kalani Nonis
 */
public class project {
    
    private String PID;
    private String location;
    private String customerNIC;
    private String customerName;
    private Date dateStarted;
    private Date submitDate;
    private String contactNo;

    public project(String PID, String location, String customerNIC, String customerName, Date dateStarted, Date submitDate, String contactNo) {
        this.PID = PID;
        this.location = location;
        this.customerNIC = customerNIC;
        this.customerName = customerName;
        this.dateStarted = dateStarted;
        this.submitDate = submitDate;
        this.contactNo = contactNo;
    }

    public String getPID() {
        return PID;
    }

    public String getLocation() {
        return location;
    }

    public String getCustomerNIC() {
        return customerNIC;
    }

    public String getCustomerName() {
        return customerName;
    }

    public Date getDateStarted() {
        return dateStarted;
    }

    public Date getSubmitDate() {
        return submitDate;
    }

    public String getContactNo() {
        return contactNo;
    }
    
    
}
