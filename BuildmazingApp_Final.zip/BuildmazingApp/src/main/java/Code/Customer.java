/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Code;

/**
 *
 * @author softlogic
 */
public class Customer {
    
    String CID;
    String name;
    String address;
    String phone;
    String gender;
    String NIC;
    String email;

    public Customer(String CID, String name, String address, String phone, String gender, String NIC, String email) {
        this.CID = CID;
        this.name = name;
        this.address = address;
        this.phone = phone;
        this.gender = gender;
        this.NIC = NIC;
        this.email = email;
    }

    public String getCID() {
        return CID;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public String getPhone() {
        return phone;
    }

    public String getGender() {
        return gender;
    }

    public String getNIC() {
        return NIC;
    }

    public String getEmail() {
        return email;
    }

    public void setCID(String CID) {
        this.CID = CID;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setNIC(String NIC) {
        this.NIC = NIC;
    }

    public void setEmail(String email) {
        this.email = email;
    }

} 

    

