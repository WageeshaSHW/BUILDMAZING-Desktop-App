/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DB;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import javax.swing.JOptionPane;

/**
 *
 * @author user
 */
public class DBConnection {

    static Connection con;

    private static void Connectdb() throws ClassNotFoundException, SQLException{
        Class.forName("com.mysql.cj.jdbc.Driver");
        con = DriverManager.getConnection("jdbc:mysql://localhost:3306/employeedb", "root", "Thili123#");

    }
    

    public static void iud(String sql) throws Exception {
        if (con == null) {
            Connectdb();
        }
        con.createStatement().executeUpdate(sql);
    }

    public static int iudReturnId(String sql) throws Exception {
        if (con == null) {
            Connectdb();
        }
        int id = 0;
        Statement statement = con.createStatement();
        int lastInsertedID = statement.executeUpdate(sql, Statement.RETURN_GENERATED_KEYS);
        ResultSet rs= statement.getGeneratedKeys();
            if (rs.next()) 
            {
              id = (int) rs.getLong(1);
            }   
        return id;
    }

    public static ResultSet search(String sql) throws Exception {
        if (con == null) {
            Connectdb();
        }
        return con.createStatement().executeQuery(sql);
    }

    public static ResultSet searchWithBackword(String sql) throws Exception {
        if (con == null) {
            Connectdb();
        }
        Statement statement = con.createStatement(ResultSet.TYPE_SCROLL_INSENSITIVE, ResultSet.CONCUR_READ_ONLY);
        return statement.executeQuery(sql);
    }

    public static Connection getDB() throws Exception {
        if (con == null) {
            Connectdb();
        }
        return con;
    }
}

