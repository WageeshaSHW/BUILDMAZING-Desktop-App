/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Code;

/**
 *
 * @author asus
 */
public class Supplier {
    String supID;
    String name;
    String address;
    String contactno;
    String email;
    String type;

    public Supplier(String supID, String name, String address, String contactno, String email, String type) {
        this.supID = supID;
        this.name = name;
        this.address = address;
        this.contactno = contactno;
        this.email = email;
        this.type = type;
    }

    public String getSupID() {
        return supID;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public String getContactno() {
        return contactno;
    }

    public String getEmail() {
        return email;
    }

    public String getType() {
        return type;
    }
}
