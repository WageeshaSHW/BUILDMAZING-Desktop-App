/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Code;

/**
 *
 * @author softlogic
 */
public class Payment {
    
    String PayID;
    String Customer;
    String CID;
    int    Quantity;
    int    Amount;
    int    Total;
    String Date;
    String Status;
    

    public Payment(String PayID, String Customer, String CID, int Quantity, int Amount, int Total, String Date, String Status) {
        
        this.PayID = PayID;
        this.Customer = Customer;
        this.CID = CID;
        this.Quantity = Quantity; 
        this.Amount = Amount;
        this.Total = Total;
        this.Date = Date;
        this.Status = Status; 
    }

    public String getCID() {
        return CID;
    }
    
    public String getPayID() {
        return PayID;
    }
    
    public String getCustomer() {
        return Customer;
    }

    public int getQuantity() {
        return Quantity;
    }

    public double getAmount() {
        return Amount;
    }

    public double getTotal() {
        return Total;
    }
  
    public String getDate() {
        return Date;
    }
    
    public String getStatus() {
        return Status;
    }
    
    

    public void setCID(String CID) {
        this.CID = CID;
    }
    
      public void setPayID(String PayID) {
        this.CID = PayID;
    }

    public void setQuantity(int Quantity) {
        this.Quantity = Quantity;
    }

    public void setAmount(int Amount) {
        this.Amount = Amount;
    }

  
    public void setTotal(int Total) {
        this.Total = Total;
    }
    
   public void setDate (String Date) {
         this.Date = Date;
    }
    
   public void set (String Status) {
         this.Status = Status;
    }
    
    
    
}

    

