/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package code;
import java.util.Date;

/**
 *
 * @author Kalani Nonis
 */
public class QRreport {
    private String QID;
    private String customerName;
    private String address;
    private Date datePrepared;
    private double totSqrFeet;
    private String contactNO;
    private double substructure;
    private double superstructure;
    private double other;
    private double total;
    private String duration;
}