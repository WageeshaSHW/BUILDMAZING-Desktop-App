/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Code;

/**
 *
 * @author Asus VivoBook X513
 */
public class Salary {
    String EID;
    String EName;
    int hoursWorked;
    double regularPay;
    double hourlyRate;
    double overtimePay;
    double totalPay;
    String date;

    public Salary(String EID, String EName, int hoursWorked, double regularPay, double hourlyRate, double overtimePay, double totalPay, String date) {
        this.EID = EID;
        this.EName = EName;
        this.hoursWorked = hoursWorked;
        this.regularPay = regularPay;
        this.hourlyRate = hourlyRate;
        this.overtimePay = overtimePay;
        this.totalPay = totalPay;
        this.date = date;
    }

    public String getEID() {
        return EID;
    }
    
    public String getEName() {
        return EName;
    }

    public int getHoursWorked() {
        return hoursWorked;
    }

    public double getRegularPay() {
        return regularPay;
    }

    public double getHourlyRate() {
        return hourlyRate;
    }

    public double getOvertimePay() {
        return overtimePay;
    }

    public double getTotalPay() {
        return totalPay;
    }
    
    public String getDate() {
        return date;
    }
    

    public void setEID(String EID) {
        this.EID = EID;
    }

    public void setHoursWorked(int hoursWorked) {
        this.hoursWorked = hoursWorked;
    }

    public void setRegularPay(double regularPay) {
        this.regularPay = regularPay;
    }

    public void setHourlyRate(double hourlyRate) {
        this.hourlyRate = hourlyRate;
    }

    public void setOvertimePay(double overtimePay) {
        this.overtimePay = overtimePay;
    }

    public void setTotalPay(double totalPay) {
        this.totalPay = totalPay;
    }
    
    
    
}
