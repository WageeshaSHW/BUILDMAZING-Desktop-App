/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Code;

/**
 *
 * @author Asus VivoBook X513
 */
public class Attendance {
    String EID;
    int hoursWorked;
    String attendance;
    String date;

    public Attendance(String EID, int hoursWorked, String attendance, String date) {
        this.EID = EID;
        this.hoursWorked = hoursWorked;
        this.attendance = attendance;
        this.date = date;
    }

    public String getEID() {
        return EID;
    }

    public int getHoursWorked() {
        return hoursWorked;
    }

    public String getAttendance() {
        return attendance;
    }

    public String getDate() {
        return date;
    }
    
    
    
}
