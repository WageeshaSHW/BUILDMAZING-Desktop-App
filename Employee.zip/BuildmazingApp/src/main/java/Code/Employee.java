/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Code;

/**
 *
 * @author Asus VivoBook X513
 */


public class Employee {

    String EID;
    String name;
    String address;
    String phone;
    String gender;
    String NIC;
    String Job;

    public Employee(String EID, String name, String address, String phone, String gender, String NIC, String Job) {
        this.EID = EID;
        this.name = name;
        this.address = address;
        this.phone = phone;
        this.gender = gender;
        this.NIC = NIC;
        this.Job = Job;
    }

    public String getEID() {
        return EID;
    }

    public String getName() {
        return name;
    }

    public String getAddress() {
        return address;
    }

    public String getPhone() {
        return phone;
    }

    public String getGender() {
        return gender;
    }

    public String getNIC() {
        return NIC;
    }

    public String getJob() {
        return Job;
    }

    public void setEID(String EID) {
        this.EID = EID;
    }

    public void setName(String name) {
        this.name = name;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public void setNIC(String NIC) {
        this.NIC = NIC;
    }

    public void setJob(String Job) {
        this.Job = Job;
    }

}
